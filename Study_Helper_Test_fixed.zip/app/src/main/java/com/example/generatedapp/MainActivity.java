package com.example.generatedapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView textInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnMath = findViewById(R.id.btnMath);
        Button btnScience = findViewById(R.id.btnScience);
        Button btnHistory = findViewById(R.id.btnHistory);
        textInfo = findViewById(R.id.textInfo);

        btnMath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textInfo.setText("गणित (Math):\n\nगणित संख्याओं, आकृतियों और उनके बीच के संबंधों का अध्ययन है। यह तर्क, बीजगणित, ज्यामिति और गणना पर आधारित है। परीक्षा में उच्च स्कोर करने के लिए सूत्रों (Formulas) का अभ्यास नियमित रूप से करें।");
            }
        });

        btnScience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textInfo.setText("विज्ञान (Science):\n\nविज्ञान प्रकृति और भौतिक जगत के नियमों का व्यवस्थित अध्ययन है। इसके प्रमुख भाग हैं - भौतिकी (Physics), रसायन विज्ञान (Chemistry) और जीव विज्ञान (Biology)। प्रयोगों और अवधारणाओं को समझकर पढ़ना विज्ञान में सफलता की कुंजी है।");
            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textInfo.setText("इतिहास (History):\n\nइतिहास अतीत की घटनाओं का कालक्रम के अनुसार अध्ययन है। इसमें प्राचीन सभ्यताओं, राजा-महाराजाओं, स्वतंत्रता संग्रामों और ऐतिहासिक तिथियों की महत्वपूर्ण जानकारी मिलती है। तिथियों और घटनाओं को कहानी के रूप में याद रखना आसान होता है।");
            }
        });
    }
}